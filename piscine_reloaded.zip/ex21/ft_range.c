/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/02 14:47:57 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 14:54:06 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int *mas;
	int i;

	if (min >= max)
	{
		mas = (void *)0;
		return (mas);
	}
	mas = (int *)malloc(sizeof(int) * (max - min));
	if ((void *)0 == mas)
		return (mas);
	i = 0;
	while (min < max)
	{
		mas[i] = min;
		min++;
		i++;
	}
	return (mas);
}
