/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/02 15:46:40 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 16:35:24 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int			main(int argc, char **argv)
{
	int		d;
	char	buf[BUF_SIZE + 1];
	int		s;
	int		i;

	if (argc == 2 && open(argv[1], O_RDONLY) != -1)
	{
		d = (open(argv[1], O_RDONLY));
		while ((s = read(d, buf, BUF_SIZE)))
		{
			buf[s] = '\0';
			i = 0;
			while (buf[i] != '\0')
			{
				ft_putchar(buf[i], 1);
				i++;
			}
			close(d);
			return (0);
		}
	}
	else
		print_error(argc);
	ft_putchar('\n', 1);
	return (1);
}
