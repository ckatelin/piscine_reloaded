/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/02 16:01:58 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 16:34:15 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# define BUF_SIZE 4096

# include <fcntl.h>
# include <unistd.h>

void	ft_putchar(char c, int d);
void	print_error(int c);
void	ft_print(char *s);

#endif
