/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/02 14:41:48 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 14:45:48 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char		*ft_strdup(char *src)
{
	char	*mas;
	int		i;

	i = 0;
	mas = (char *)malloc(sizeof(src));
	if ((void *)0 == mas)
		return (src);
	while (src[i] != '\0')
	{
		mas[i] = src[i];
		i++;
	}
	mas[i] = '\0';
	return (mas);
}
