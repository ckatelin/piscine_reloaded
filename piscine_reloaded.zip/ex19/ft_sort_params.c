/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 18:51:27 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 14:39:47 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void		ft_putchar(char c);

int			ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while ((*(s1 + i) != '\0' || *(s2 + i) != '\0'))
	{
		if (*(s1 + i) == '\0' && *(s2 + i) != '\0')
			return (-1);
		if (*(s1 + i) != '\0' && *(s2 + i) == '\0')
			return (1);
		if (*(s1 + i) < *(s2 + i))
			return (-1);
		if (*(s1 + i) > *(s2 + i))
			return (1);
		i++;
	}
	return (0);
}

void		ft_putstr(char *str)
{
	while (*str != '\0')
	{
		ft_putchar(*str);
		str++;
	}
}

void		ft_print(char **argv, int argc)
{
	int		i;

	i = 1;
	while (i < argc)
	{
		ft_putstr(argv[i]);
		ft_putchar('\n');
		i++;
	}
}

int			main(int argc, char **argv)
{
	int		i;
	int		j;
	char	*tmp;

	i = 1;
	if (argc > 0)
	{
		while (i < (argc))
		{
			j = i + 1;
			while (j < (argc))
			{
				if (ft_strcmp(argv[i], argv[j]) == 1)
				{
					tmp = argv[i];
					argv[i] = argv[j];
					argv[j] = tmp;
				}
				j++;
			}
			i++;
		}
	}
	ft_print(argv, argc);
	return (0);
}
